from fastapi import FastAPI
from cassandra.cluster import Cluster
from datetime import datetime, timedelta
import uvicorn
import asyncio

# ✅ Connexion à Cassandra
cluster = Cluster(["127.0.0.1"], port=9042)
session = cluster.connect()
session.set_keyspace("digitransit_db")

# ✅ Création de l'application FastAPI
app = FastAPI()

# ✅ 1. Endpoint pour récupérer la dernière position d’un bus donné
@app.get("/bus/{vehicle_id}")
def get_last_position(vehicle_id: str):
    query = f"SELECT * FROM BusPositions WHERE vehicle_id = '{vehicle_id}' LIMIT 1;"
    rows = session.execute(query)
    for row in rows:
        return {
            "vehicle_id": row.vehicle_id,
            "latitude": row.latitude,
            "longitude": row.longitude,
            "timestamp": row.timestamp
        }
    return {"error": "Aucune donnée trouvée"}

# ✅ 2. Endpoint pour récupérer le nombre de trajets par ligne aujourd’hui
@app.get("/trips")
def get_trips_per_line():
    time_limit = datetime.utcnow() - timedelta(days=1)
    query = "SELECT route_id, timestamp FROM BusPositions ALLOW FILTERING;"
    rows = session.execute(query)

    trajets_par_ligne = {}
    for row in rows:
        if row.timestamp >= time_limit:
            trajets_par_ligne[row.route_id] = trajets_par_ligne.get(row.route_id, 0) + 1

    return trajets_par_ligne

# ✅ 3. Endpoint pour récupérer les prochains passages à un arrêt donné
@app.get("/next_stop/{stop_id}")
def get_next_bus(stop_id: str):
    query = f"SELECT * FROM BusPositions WHERE next_stop_id = '{stop_id}' ALLOW FILTERING;"
    rows = session.execute(query)

    next_buses = []
    for row in rows:
        next_buses.append({
            "vehicle_id": row.vehicle_id,
            "route_id": row.route_id,
            "timestamp": row.timestamp
        })
        if len(next_buses) >= 3:
            break

    return next_buses

# ✅ 4. Endpoint pour récupérer le retard moyen par ligne
@app.get("/delays")
def get_avg_delay():
    query = "SELECT route_id, AVG(delay) AS retard_moyen FROM BusDelays GROUP BY route_id;"
    rows = session.execute(query)

    delays = {}
    for row in rows:
        if row.retard_moyen is not None:
            delays[row.route_id] = round(row.retard_moyen, 2)

    return delays



if __name__ == "__main__":
    try:
        loop = asyncio.get_running_loop()
        loop.create_task(uvicorn.run(app, host="0.0.0.0", port=8000))
    except RuntimeError:  # Si aucun event loop n'est en cours
        uvicorn.run(app, host="0.0.0.0", port=8000)
