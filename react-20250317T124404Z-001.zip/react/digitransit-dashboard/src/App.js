import React, { useState, useEffect } from "react";
import axios from "axios";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";

const API_BASE_URL = "http://127.0.0.1:8000"; // Adresse de l'API FastAPI

function App() {
  const [busData, setBusData] = useState([]);
  const [trips, setTrips] = useState({});
  const [delays, setDelays] = useState({});
  const [selectedBus, setSelectedBus] = useState("403");
  const [stopId, setStopId] = useState("1384161");

  // ✅ Fonction pour récupérer les trajets
  const fetchTrips = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/trips`);
      console.log("📊 Données trajets reçues :", response.data); // 🔍 Vérifier les données
      setTrips(response.data);
    } catch (error) {
      console.error("❌ Erreur trajets :", error);
    }
  };

  // ✅ Fonction pour récupérer les retards
  const fetchDelays = async () => {
    try {
      const response = await axios.get(`${API_BASE_URL}/delays`);
      console.log("⏳ Données retards reçues :", response.data); // 🔍 Vérifier les données
      setDelays(response.data);
    } catch (error) {
      console.error("❌ Erreur retards :", error);
    }
  };

  useEffect(() => {
    fetchTrips();
    fetchDelays();
  }, []); // ✅ Charge les données une seule fois au chargement de la page

  console.log("🔍 Debug global :", { trips, delays });

  return (
    <div style={{ textAlign: "center", padding: "20px" }}>
      <h1>🚌 Dashboard Digitransit</h1>

      {/* Recherche d'un bus */}
      <div>
        <label>🔍 Rechercher un bus : </label>
        <input 
          type="text" 
          value={selectedBus} 
          onChange={(e) => setSelectedBus(e.target.value)} 
        />
      </div>

      {/* 📊 Nombre de trajets par ligne */}
      <h2>📊 Nombre de trajets par ligne</h2>
      {console.log("🚀 Debug trips :", trips)}
      {Object.keys(trips).length > 0 ? (
        <table border="1" style={{ margin: "auto", width: "60%", textAlign: "center" }}>
          <thead>
            <tr style={{ backgroundColor: "#007bff", color: "white" }}>
              <th>Ligne</th>
              <th>Nombre de trajets</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(trips).map(([route, count]) => (
              <tr key={route}>
                <td>{route}</td>
                <td>{count}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>⏳ Chargement des trajets...</p>
      )}

      {/* ⏳ Retard moyen par ligne */}
      <h2>⏳ Retard moyen par ligne</h2>
      {console.log("🚀 Debug delays :", delays)}
      {Object.keys(delays).length > 0 ? (
        <table border="1" style={{ margin: "auto", width: "60%", textAlign: "center" }}>
          <thead>
            <tr style={{ backgroundColor: "#ff4500", color: "white" }}>
              <th>Ligne</th>
              <th>Retard moyen (s)</th>
            </tr>
          </thead>
          <tbody>
            {Object.entries(delays).map(([route, delay]) => (
              <tr key={route}>
                <td>{route}</td>
                <td>{delay}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>⏳ Chargement des retards...</p>
      )}
    </div>
  );
}

export default App;
