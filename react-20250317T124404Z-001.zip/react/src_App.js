import React, { useState, useEffect } from "react";
import axios from "axios";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";

const API_BASE_URL = "http://127.0.0.1:8000"; // Adresse de l'API FastAPI

function App() {
  const [busData, setBusData] = useState([]);
  const [trips, setTrips] = useState({});
  const [delays, setDelays] = useState({});
  const [selectedBus, setSelectedBus] = useState("403"); // Bus par défaut
  const [stopId, setStopId] = useState("1384161");

  // ✅ Fonction pour récupérer les données des bus
  const fetchBusData = () => {
    axios.get(`${API_BASE_URL}/bus/${selectedBus}`)
      .then((response) => setBusData([response.data]))
      .catch((error) => console.error("Erreur lors de la récupération des données du bus :", error));
  };

  // ✅ Fonction pour récupérer les trajets
  const fetchTrips = () => {
    axios.get(`${API_BASE_URL}/trips`)
      .then((response) => setTrips(response.data))
      .catch((error) => console.error("Erreur lors de la récupération des trajets :", error));
  };

  // ✅ Fonction pour récupérer les retards
  const fetchDelays = () => {
    axios.get(`${API_BASE_URL}/delays`)
      .then((response) => setDelays(response.data))
      .catch((error) => console.error("Erreur lors de la récupération des retards :", error));
  };

  // ✅ Rafraîchissement automatique toutes les 10 secondes
  useEffect(() => {
    fetchBusData();
    fetchTrips();
    fetchDelays();

    const interval = setInterval(() => {
      fetchBusData();
      fetchTrips();
      fetchDelays();
    }, 10000); // Met à jour toutes les 10 secondes

    return () => clearInterval(interval);
  }, [selectedBus]);

  return (
    <div style={{ textAlign: "center", padding: "20px" }}>
      <h1>🚌 Dashboard Digitransit</h1>

      {/* Sélection du bus */}
      <div>
        <label>🔍 Rechercher un bus : </label>
        <input
          type="text"
          value={selectedBus}
          onChange={(e) => setSelectedBus(e.target.value)}
        />
      </div>

      {/* Carte interactive */}
      <MapContainer center={[60.1695, 24.9354]} zoom={12} style={{ height: "400px", width: "100%" }}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
        {busData.map((bus, index) => (
          <Marker key={index} position={[bus.latitude, bus.longitude]}>
            <Popup>
              🚌 Bus {bus.vehicle_id} <br />
              📍 Latitude: {bus.latitude} <br />
              📍 Longitude: {bus.longitude} <br />
              ⏳ Dernière mise à jour: {bus.timestamp}
            </Popup>
          </Marker>
        ))}
      </MapContainer>

      {/* Tableau des trajets */}
      <h2>📊 Nombre de trajets par ligne</h2>
      <table border="1" style={{ margin: "auto" }}>
        <thead>
          <tr>
            <th>Ligne</th>
            <th>Nombre de trajets</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(trips).map(([route, count]) => (
            <tr key={route}>
              <td>{route}</td>
              <td>{count}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Tableau des retards */}
      <h2>⏳ Retard moyen par ligne</h2>
      <table border="1" style={{ margin: "auto" }}>
        <thead>
          <tr>
            <th>Ligne</th>
            <th>Retard moyen (s)</th>
          </tr>
        </thead>
        <tbody>
          {Object.entries(delays).map(([route, delay]) => (
            <tr key={route}>
              <td>{route}</td>
              <td>{delay}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Sélection de l'arrêt */}
      <div>
        <label>🚏 Arrêt : </label>
        <input
          type="text"
          value={stopId}
          onChange={(e) => setStopId(e.target.value)}
        />
      </div>
    </div>
  );
}

export default App;
